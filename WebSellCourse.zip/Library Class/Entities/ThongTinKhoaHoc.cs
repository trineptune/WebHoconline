﻿using System;
using System.Collections.Generic;

namespace Library_Class.Entities
{
    public partial class ThongTinKhoaHoc
    {
        public string? TenNganhHoc { get; set; }
        public string? TenKhoaHoc { get; set; }
        public string? Ten { get; set; }
    }
}
